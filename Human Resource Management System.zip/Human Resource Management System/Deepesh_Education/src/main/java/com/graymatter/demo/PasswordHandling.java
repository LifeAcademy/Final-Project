package com.graymatter.demo;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
public class PasswordHandling {
	public static void main(String[] arg){
		
		 BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
	    System.out.println("encoder:  " + encoder.encode("admin"));
	    System.out.println("encoder:  " + encoder.encode("user"));
	    System.out.println("encoder:  " + encoder.encode("Deepesh@123"));
	    System.out.println("encoder:  " + encoder.encode("Karthika@123"));
	    System.out.println("encoder:  " + encoder.encode("Vishal@123"));
	    System.out.println("encoder:  " + encoder.encode("Hamida@123"));
	    System.out.println("encoder:  " + encoder.encode("Guru@123"));

	}
	}