<!DOCTYPE html>
<html>

<head>
	<title>My Shopping Cart</title>
	<link rel="stylesheet" type="text/css" href="styles/styles.css">
</head>

<body>
<center>
	<img src="images/cart.png" width="200" height="200" alt="Shopping Cart Image" class="logo">
	<h1 >Shopping Cart</h1>
	<h3 >The Online Shopping Store</h3>
</center>

<hr class="1">

<ul>
	<li><a>Home</a></li>
	<li><a>News</a></li>
	<li><a>Contact</a></li>
	<li><a>About Us</a></li>
</ul>
<!DOCTYPE html>
<html>

<head>
	<title>My Shopping Cart</title>
	<link rel="stylesheet" type="text/css" href="styles/styles.css">
</head>

<body>
<center>
	<img src="images/cart.png" width="200" height="200" alt="Shopping Cart Image" class="logo">
	<h1 >Shopping Cart</h1>
	<h3 >The Online Shopping Store</h3>
</center>

<hr class="1">

<ul>
	<li><a>Home</a></li>
	<li><a>News</a></li>
	<li><a>Contact</a></li>
	<li><a>About Us</a></li>
</ul>
<script>
	document.write("7/29/2019");
</script>
<hr class="1">
<h3 class="1">Created By : <a href="https://courseweb.sliit.lk/"> Navodya Tharindi Pasqual </a></h3>
<h3>Visit to our course</h3>
</center>
</body>
</html>