package com.graymatter.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DeepeshEducationApplicationTests {

	@Test
	void contextLoads() {
	}

}
